import React, { Component } from "react";
import logo from "./logo.svg";
import "./App.scss";
import Taglist from "./components/taglist";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      title: "Radio Free Task by Ulya (React)",
      placeholder: "Enter a tag...",
      list: ["red", "blue"]
    };
  }

  render() {
    return (
      <React.Fragment>
        <main className="container">
          <div>
            <h3>{this.state.title}</h3>
            <form>
              <label>
                Tag:
                <input
                  type="text"
                  className="tag"
                  id="tag"
                  placeholder={this.state.placeholder}
                />
              </label>
            </form>
          </div>
          <Taglist onAdd={this.handleAdd} onRemove={this.handleRemove} />
        </main>
      </React.Fragment>
    );
  }
}

export default App;
