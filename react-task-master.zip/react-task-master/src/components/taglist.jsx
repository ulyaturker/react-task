import React, { Component } from "react";

class Taglist extends Component {
  constructor(props) {
    super(props);
    this.state = {
      list: ["red", "blue", "purple"]
    };
  }

  componentDidUpdate() {
    //Set url
    window.location = "#tags:" + this.state.list;
    document.getElementById("tag").value = "";
  }

  handleRemove = index => {
    // Remove Tag
    const filteredItems = this.state.list.filter(
      item => item !== this.state.list[index]
    );
    this.setState({ list: filteredItems });
  };

  handleAdd = () => {
    var newtag = document.getElementById("tag").value; //get new tag
    if (this.state.list.some(item => newtag === item)) {
      //if the tag is added before
      alert("This item is added before! Enter new tag...");
    } else if (newtag == "") {
      //if new tag is null
      alert("You cannot enter null tag!");
    } else {
      //Add Tag
      this.setState(state => {
        const list = [...state.list, newtag];
        console.log(list);
        return {
          list
        };
      });
    }
  };

  render() {
    return (
      <React.Fragment>
        <div>
          <button
            className="btn btn-secondary btn-sm m-2 "
            type="submit"
            onClick={this.handleAdd}
          >
            ADD TAG
          </button>
          <ul id="ullist">
            {this.state.list.map((item, index) => (
              <li
                onClick={() => {
                  this.handleRemove(index);
                }}
                key={index}
                item={item}
              >
                {item}
              </li>
            ))}
          </ul>
        </div>
      </React.Fragment>
    );
  }
}
export default Taglist;
